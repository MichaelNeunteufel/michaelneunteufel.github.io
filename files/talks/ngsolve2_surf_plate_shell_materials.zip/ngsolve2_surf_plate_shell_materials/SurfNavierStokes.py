from ngsolve import *
from netgen.csg import *
from ngsolve.internal import visoptions

from math import pi

geo = CSGeometry()

####shell######
r = 2/pi
cyl = Cylinder(Pnt(r,0,0), Pnt(r,1,0),r)
top = Plane(Pnt(0,0.41,0),Vec(0,1,0))
up = Plane(Pnt(0,0,0),Vec(0,0,-1))
bot = Plane(Pnt(0,0,0),Vec(0,-1,0))

holecoorx = cos(0.2/r)*r
holecoorz = sin(0.2/r)*r
hole = Cylinder( Pnt(r,0.2,0), Pnt(-holecoorx+r,0.2,holecoorz),0.05)

shell = (cyl * top*bot*up - hole).bc("dir")

geo.AddSurface(cyl, shell)
################


def SetFreeDofs(V, bt):
    neumannindex = 2
    for el in V.components[0].Elements(BBND):
        if el.index != neumannindex:
            for dofs in el.dofs:            
                bt.Clear(dofs)
            
    for el in V.components[1].Elements(BBND):
        if el.index != neumannindex:
            for dofs in el.dofs:            
                bt.Clear(dofs+V.components[0].ndof)
            
mesh = Mesh(geo.GenerateMesh(maxh=0.1))
Draw(mesh)

order = 3
mesh.Curve(order)
alpha = 4
nu = 0.001
tau = 0.001

VDivSurf = HDivSurface(mesh, order = order)
VHat = HCurl(mesh, order = order, flags={"orderface": 0})
Q = SurfaceL2(mesh, order = order-1)

V = FESpace([VDivSurf,VHat,Q])

u, uhat, p = V.TrialFunction()
v, vhat, q = V.TestFunction()


normal = specialcf.normal(3)
tangential = specialcf.tangential(3)
n = Cross(normal,tangential)

def tang(vec):
    return vec - (vec*n)*n

h = specialcf.mesh_size

gradu = CoefficientFunction ( (grad(u),), dims=(3,3) )
gradv = CoefficientFunction ( (grad(v),), dims=(3,3) )

uhat, vhat = uhat.Trace(), vhat.Trace()
u, v = u.Trace(), v.Trace()
p, q = p.Trace(), q.Trace()

m = BilinearForm(V)
m += SymbolicBFI( u*v, BND )
m.Assemble()

a = BilinearForm(V)
a += SymbolicBFI( nu*InnerProduct(gradu, gradv), BND)
a += SymbolicBFI( nu*InnerProduct( gradu.trans*n, tang(vhat-v) ), BND, element_boundary=True )
a += SymbolicBFI( nu*InnerProduct( gradv.trans*n, tang(uhat-u) ), BND, element_boundary=True )
a += SymbolicBFI( nu*4*order*order/h * InnerProduct( tang(vhat-v), tang(uhat-u) ) ,BND, element_boundary=True )
a += SymbolicBFI ( div(u)*q + div(v)*p - 1e-8*p*q, BND )
a.Assemble()

conv = BilinearForm(V)
conv += SymbolicBFI( -InnerProduct(gradv*u, u), BND )


u_Other = (u*n)*n + tang(uhat)

conv += SymbolicBFI( u*n*IfPos(u*n, u*v, u_Other*v), BND, element_boundary = True)


U0 = 1.5
uin = CoefficientFunction(U0*4*y*(0.41-y)/(0.41*0.41) * IfPos(1e-2-x,1,0))
dirvals = CoefficientFunction( (0, 0, uin) )

gfu = GridFunction(V)
gfu.components[0].Set(dirvals, definedon = mesh.Boundaries("dir"))
gfu.components[1].Set(dirvals, definedon = mesh.Boundaries("dir"))

bt = V.FreeDofs()
SetFreeDofs(V, bt)

invstokes = a.mat.Inverse(bt, inverse ="sparsecholesky")
res = gfu.vec.CreateVector()
res.data = a.mat*gfu.vec
gfu.vec.data -= invstokes * res

mstar = m.mat.CreateMatrix()
mstar.AsVector().data = m.mat.AsVector() + tau * a.mat.AsVector()
inv = mstar.Inverse(bt, inverse="sparsecholesky")

Draw(gfu.components[2], mesh, "pressure")
Draw(gfu.components[0], mesh, "velocity")
visoptions.scalfunction = "velocity:0"

tend = 10
t = 0
convvec = gfu.vec.CreateVector()

with TaskManager():
    while t < tend:
        print ("t = ", t)

        conv.Apply(gfu.vec,convvec)          
        res.data = a.mat * gfu.vec + convvec
        gfu.vec.data -= tau * inv * res    

        t += tau
        Redraw()
