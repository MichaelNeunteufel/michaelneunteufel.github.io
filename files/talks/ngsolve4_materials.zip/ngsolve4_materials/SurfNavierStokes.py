from ngsolve import *
import netgen.csg as csg
from ngsolve.internal import visoptions
from netgen.occ import *
from time import sleep
from ngsolve.internal import SnapShot


####shell######
r = 2/pi
if False:
    geo = csg.CSGeometry()
    cyl   = csg.Cylinder(csg.Pnt(r,0,0), csg.Pnt(r,1,0),r)
    top   = csg.Plane(csg.Pnt(0,0.41,0),csg.Vec(0,1,0))
    up    = csg.Plane(csg.Pnt(0,0,0),csg.Vec(0,0,-1))
    bot   = csg.Plane(csg.Pnt(0,0,0),csg.Vec(0,-1,0))
    right = csg.Plane(csg.Pnt(4/pi-1e-5,0,0),csg.Vec(1,0,0))
    
    holecoorx = cos(0.2/r)*r
    holecoorz = sin(0.2/r)*r
    hole = csg.Cylinder( csg.Pnt(r,0.2,0), csg.Pnt(-holecoorx+r,0.2,holecoorz),0.05)
    
    shell = cyl * top*bot*right*up - hole
    
    geo.AddSurface(cyl, shell)
    
    geo.NameEdge(cyl, bot, "wall")
    geo.NameEdge(cyl, top, "wall")
    geo.NameEdge(cyl, hole, "wall")
    geo.NameEdge(cyl, up, "inlet")
    geo.NameEdge(cyl, right, "outlet")

    mesh = Mesh(geo.GenerateMesh(maxh=0.1))
else:
    p1 = gp_Pnt
    p2 = gp_Pnt
    p3 = gp_Pnt
    
    arc = ArcOfCircle((0,0.41,0),(r,0.41,r),(2*r,0.41,0))
    shell = Prism(arc, (0,-0.41,0))

    holecoorx = cos(0.2/r)*r
    holecoorz = sin(0.2/r)*r
    hole = Cylinder((r,0.2,0), -holecoorx*X+holecoorz*Z, r=0.05, h=2)
    surf = shell-hole

    surf.edges.name="wall"
    for e in shell.SubShapes(EDGE):
        rho,c = e.Properties()
        if c.x < 0.01:
            e.name = "inlet"
        if c.x > 2*r-0.01:
            e.name = "outlet"
            
    geo = OCCGeometry(surf)
    mesh = Mesh(geo.GenerateMesh(maxh=0.1))
    
Draw(mesh)

order = 3
mesh.Curve(order)
alpha = 4
nu = 0.001
tau = 0.001

VDivSurf = HDivSurface(mesh, order=order, dirichlet_bbnd="inlet|wall")
VHat = HCurl(mesh, order=order, flags={"orderface": 0}, dirichlet_bbnd="inlet|wall")
Q = SurfaceL2(mesh, order=order-1)
V = VDivSurf*VHat*Q

u, uhat,p = V.TrialFunction()
v, vhat,q = V.TestFunction()


normal = specialcf.normal(3)
tangential = specialcf.tangential(3)
n = Cross(normal,tangential)

def tang(vec):
    return vec - (vec*n)*n

h = specialcf.mesh_size

proj = Id(3) - OuterProduct(normal,normal)

vhat = vhat.Trace()
uhat = uhat.Trace()

m = BilinearForm(V, symmetric=True)
m += u.Trace()*v.Trace()*ds
m.Assemble()
print("finished assembling m")

a = BilinearForm(V, symmetric=True)
a += nu*InnerProduct(proj*Grad(u), proj*Grad(v))*ds
a += nu* InnerProduct ( proj*Grad(u) * n,  tang(vhat-v.Trace()) )*ds(element_boundary=True)
a += nu*InnerProduct ( proj*Grad(v) * n,  tang(uhat-u.Trace()) )*ds(element_boundary=True)
a += nu* 4*order*order/h * InnerProduct ( tang(vhat-v.Trace()),  tang(uhat-u.Trace()) )*ds(element_boundary=True)
a += (div(u.Trace()) *q.Trace() + div(v.Trace()) *p.Trace() - 1e-8*p.Trace() *q.Trace())*ds
a.Assemble()
print("finished assembling a")

conv = BilinearForm(V)
conv += -InnerProduct(proj*Grad(v)*u.Trace(), u.Trace())*ds

u_Other = (u.Trace()*n)*n + tang(uhat)

conv += IfPos(u.Trace() * n, u.Trace()*n*u.Trace()*v.Trace(), u.Trace()*n*u_Other*v.Trace())*ds(element_boundary=True)


f = LinearForm(V)
f.Assemble()
print("finished assembling f")

U0 = 1.5
uin = CF(U0*4*y*(0.41-y)/(0.41*0.41) * IfPos(1e-2-x,1,0))
dirvals = CF(( 0,0,uin) )
Draw(cf =dirvals, mesh = mesh, name = "dirvals")

gfu = GridFunction(V)
gfu.components[0].Set(dirvals, definedon=mesh.Boundaries(".*"))
gfu.components[1].Set(dirvals, definedon=mesh.Boundaries(".*"))


invstokes = a.mat.Inverse(V.FreeDofs(), inverse ="sparsecholesky")
res = gfu.vec.CreateVector()
res.data = f.vec - a.mat*gfu.vec
gfu.vec.data += invstokes * res

mstar = m.mat.CreateMatrix()
mstar.AsVector().data = m.mat.AsVector() + tau * a.mat.AsVector()
inv = mstar.Inverse(V.FreeDofs(), inverse="sparsecholesky")

velocity = CoefficientFunction(gfu.components[0])
pressure = CoefficientFunction(gfu.components[2])
Draw(cf = pressure, mesh = mesh, name = "pressure")
Draw(cf =velocity, mesh = mesh, name = "velocity")
visoptions.scalfunction = "velocity:0"

tend = 10
t = 0
convvec = gfu.vec.CreateVector()


i = 0

input("press enter to start")

with TaskManager():
    while t < tend:
        print ("t = ", t)
        conv.Apply(gfu.vec,convvec)          
        res.data = a.mat * gfu.vec + convvec
        gfu.vec.data -= tau * inv * res    


        if i % 20 == 0:
            Redraw(blocking=True)
            sleep(0.3)
            SnapShot("video/navstokes_"+str(int(i/20)+1)+".png")
            sleep(0.3)

        i += 1
        t += tau
