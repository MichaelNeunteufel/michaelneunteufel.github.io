from ngsolve import *
from netgen.csg import *

geo          = CSGeometry()
sphere       = Sphere(Pnt(0,0,0), 1)
bot          = Plane(Pnt(0,0,0), Vec(0,0,-1))
finitesphere = sphere * bot

geo.AddSurface(sphere, finitesphere.bc("surface"))
geo.NameEdge(sphere,bot, "bottom")

mesh = Mesh(geo.GenerateMesh(maxh=0.3))
mesh.Curve(4)
Draw(mesh)

fes = H1(mesh, order=4, dirichlet_bbnd="bottom")
u, v = fes.TnT()
print(fes.FreeDofs())

a = BilinearForm(fes, symmetric=True)
a += grad(u).Trace()*grad(v).Trace()*ds
a.Assemble()

force = 20*sin(x)*y*exp(z)

f = LinearForm(fes)
f += force*v*ds
f.Assemble();

gfu = GridFunction(fes)
gfu.Set(x, definedon=mesh.BBoundaries("bottom"))
r = f.vec.CreateVector()
r.data = f.vec - a.mat*gfu.vec
gfu.vec.data += a.mat.Inverse(fes.FreeDofs())*r

Draw(gfu, mesh, "u")
Draw(Grad(gfu),mesh, "gradu")
