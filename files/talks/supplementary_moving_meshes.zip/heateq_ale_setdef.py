from ngsolve import *
from netgen.geom2d import unit_square
from math import pi

t    = 0
tau  = 1e-3
tend = 0.1


def Deformation(t):
    return CoefficientFunction( (0.3*sin(2*t*pi*x)*y*(1-y), 0.3*sin(2*t*pi*y)*x*(1-x)) )

mesh = Mesh(unit_square.GenerateMesh(maxh=0.1))
Draw(mesh)

fesset = H1(mesh, order=3, dirichlet=".*", dim=2)
fes = H1(mesh, order=3, dirichlet= ".*")
u,v = fes.TnT()

gfu      = GridFunction(fes)
gfuold   = GridFunction(fes)
gfset    = GridFunction(fesset)
gfsetold = GridFunction(fesset)


diffusion = InnerProduct(grad(u), grad(v))*dx(deformation=gfset)
mass      = u*v*dx(deformation=gfset)
conv      = -InnerProduct(grad(u), 1/tau*(gfset-gfsetold))*v*dx(deformation=gfset)
force     = 10*v*dx(deformation=gfset)

a = BilinearForm(fes,symmetric=True)
a += diffusion
a.Assemble()

m = BilinearForm(fes, symmetric=True)
m += mass
m.Assemble()

mstar = a.mat.CreateMatrix()

b = BilinearForm(fes, nonassemble=True)
b += conv

f = LinearForm(fes)
f += force

# initial value
gfu.Set( exp( -100*((x-0.5)**2+(y-0.5)**2) ) )

Draw(gfu, mesh, "u")
Draw(gfset, mesh, "deformation")
SetVisualization(deformation=True)

r = gfu.vec.CreateVector()

with TaskManager():
  while t < tend:
    t += tau
    print("t = ", t)

    gfsetold.vec.data = gfset.vec
    gfset.Set(Deformation(t/tend))
    gfuold.vec.data = gfu.vec

    b.Apply(gfu.vec, r)    

    a.Assemble()
    m.Assemble()
    mstar.AsVector().data = m.mat.AsVector() + tau*a.mat.AsVector()
    f.Assemble()

    r.data -= f.vec
    r.data += a.mat*gfu.vec

    inv = mstar.Inverse(fes.FreeDofs(), inverse="umfpack")

    gfu.vec.data -= tau*inv*r
      
    Redraw(blocking=True)
