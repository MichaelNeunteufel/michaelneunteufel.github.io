from ngsolve import *
from netgen.geom2d import SplineGeometry
from ngsolve.internal import *
from math import pi


def GenerateMeshParticle(maxh=0.1, L=2.5, H=0.41):
    ro = 0.01
    mxo = 0.12
    myo = 0.12

    geom = SplineGeometry()
    pnts = [ (0,0,maxh), (L,0,maxh), (L,H,maxh), (0,H,maxh), (0.5,0.23,maxh), (0.5,0.27,maxh), (0.52,0.23,maxh), (0.52,0.27,maxh), (0.2,0.17,maxh/15),(0.248989794855664,0.17,maxh),(0.248989794855664,0.23,maxh),(0.2,0.23,maxh/15), (0.4,0.10,maxh), (0.4,0.14,maxh), (0.42,0.10,maxh), (0.42,0.14,maxh), (0.34,0.22,maxh), (0.34,0.26,maxh), (0.36,0.22,maxh), (0.36,0.26,maxh), (mxo,myo-ro,maxh), (mxo+ro,myo-ro,maxh), (mxo+ro,myo,maxh), (mxo+ro,myo+ro,maxh), (mxo,myo+ro,maxh), (mxo-ro,myo+ro,maxh), (mxo-ro,myo,maxh), (mxo-ro,myo-ro,maxh)]
    pind = [ geom.AppendPoint(*pnt) for pnt in pnts ]
    for p in pnts:
        print(p)
    geom.Append(['line',pind[0],pind[1]],leftdomain=1,rightdomain=0,bc="wall")
    geom.Append(['line',pind[1],pind[2]],leftdomain=1,rightdomain=0,bc="outlet")
    geom.Append(['line',pind[2],pind[3]],leftdomain=1,rightdomain=0,bc="wall")
    geom.Append(['line',pind[3],pind[0]],leftdomain=1,rightdomain=0,bc="inlet")

    geom.Append(['line',pind[8],pind[9]],leftdomain=0,rightdomain=1,bc="outcyl",maxh=maxh/10)
    geom.Append(['line',pind[9],pind[10]],leftdomain=0,rightdomain=1,bc="outcyl",maxh=maxh/10)
    geom.Append(['line',pind[10],pind[11]],leftdomain=0,rightdomain=1,bc="outcyl",maxh=maxh/10)
    geom.Append(['line',pind[11],pind[8]],leftdomain=0,rightdomain=1,bc="outcyl",maxh=maxh/10)
    
    geom.Append(['line',pind[4],pind[6]],leftdomain=2,rightdomain=1,bc="interface")
    geom.Append(['line',pind[6],pind[7]],leftdomain=2,rightdomain=1,bc="interface")
    geom.Append(['line',pind[7],pind[5]],leftdomain=2,rightdomain=1,bc="interface")
    geom.Append(['line',pind[5],pind[4]],leftdomain=2,rightdomain=1,bc="interface")

    geom.Append(['line',pind[12],pind[14]],leftdomain=2,rightdomain=1,bc="interface")
    geom.Append(['line',pind[14],pind[15]],leftdomain=2,rightdomain=1,bc="interface")
    geom.Append(['line',pind[15],pind[13]],leftdomain=2,rightdomain=1,bc="interface")
    geom.Append(['line',pind[13],pind[12]],leftdomain=2,rightdomain=1,bc="interface")

    geom.Append(['line',pind[16],pind[18]],leftdomain=2,rightdomain=1,bc="interface")
    geom.Append(['line',pind[18],pind[19]],leftdomain=2,rightdomain=1,bc="interface")
    geom.Append(['line',pind[19],pind[17]],leftdomain=2,rightdomain=1,bc="interface")
    geom.Append(['line',pind[17],pind[16]],leftdomain=2,rightdomain=1,bc="interface")

    
    geom.Append(['spline3',pind[20],pind[21],pind[22]],leftdomain=2,rightdomain=1,bc="interface")
    geom.Append(['spline3',pind[22],pind[23],pind[24]],leftdomain=2,rightdomain=1,bc="interface")
    geom.Append(['spline3',pind[24],pind[25],pind[26]],leftdomain=2,rightdomain=1,bc="interface")
    geom.Append(['spline3',pind[26],pind[27],pind[20]],leftdomain=2,rightdomain=1,bc="interface")
    
    geom.SetMaterial(1, "fluid")
    geom.SetMaterial(2, "solid")
    ngmesh = geom.GenerateMesh(maxh = maxh)
    ngmesh.SecondOrder()
    mesh = Mesh(ngmesh)
    
    return mesh



def Generate2DMesh(order, maxh=0.12, L=2.5, H=0.41, printing=False):
    r = 0.05
    D = 0.1

    if printing:
        print("Generating mesh")
        print("order = ", order)
        print("maxh = ", maxh)
        print("Length = ", L)
        print("Height = ", H)
        print("Radius of circle = ", r)

    geom = SplineGeometry()
    pnts = [ (0,0), (L,0), (L,H), (0,H), (0.2,0.15), (0.240824829046386,0.15), (0.248989794855664,0.19), (0.25,0.2), (0.248989794855664,0.21), (0.240824829046386,0.25), (0.2,0.25), (0.15,0.25), (0.15,0.2), (0.15,0.15), (0.6,0.19), (0.6,0.21), (0.55,0.19), (0.56,0.15), (0.6,0.15), (0.65,0.15), (0.65,0.2),(0.65,0.25), (0.6,0.25), (0.56,0.25), (0.55,0.21), (0.65,0.25),(0.65,0.15) ]
    pind = [ geom.AppendPoint(*pnt) for pnt in pnts ]

    geom.Append(['line',pind[0],pind[1]],leftdomain=1,rightdomain=0,bc="wall")
    geom.Append(['line',pind[1],pind[2]],leftdomain=1,rightdomain=0,bc="outlet")
    geom.Append(['line',pind[2],pind[3]],leftdomain=1,rightdomain=0,bc="wall")
    geom.Append(['line',pind[3],pind[0]],leftdomain=1,rightdomain=0,bc="inlet")

    geom.Append(['spline3',pind[4],pind[5],pind[6]],leftdomain=0,rightdomain=1,bc="circ")
    geom.Append(['spline3',pind[6],pind[7],pind[8]],leftdomain=0,rightdomain=2,bc="circ2")
    geom.Append(['spline3',pind[8],pind[9],pind[10]],leftdomain=0,rightdomain=1,bc="circ")
    geom.Append(['spline3',pind[10],pind[11],pind[12]],leftdomain=0,rightdomain=1,bc="circ")
    geom.Append(['spline3',pind[12],pind[13],pind[4]],leftdomain=0,rightdomain=1,bc="circ")

    geom.Append(['line',pind[6],pind[14]],leftdomain=2,rightdomain=1,bc="interface")
    geom.Append(['line',pind[14],pind[15]],leftdomain=2,rightdomain=1,bc="interface")
    geom.Append(['line',pind[15],pind[8]],leftdomain=2,rightdomain=1,bc="interface")


    geom.SetMaterial(1, "fluid")
    geom.SetMaterial(2, "solid")
    
    mesh = Mesh(geom.GenerateMesh(maxh=maxh))
    mesh.Curve(order)
    
    return mesh


def CalcStresses(A):
    I = Id(2)
    F = A + I
    C = F.trans*F
    E = 0.5*(C - I)
    J = Det(F)
    Finv = Inv(F)
    return (F, C, E, J, Finv)


def SetCoeff(selection):
    (rhos, ls, mus, rhof, nuf, U) = (0,0,0,0,0,0)
    if(selection == 1):
        rhos = 1e3
        nus = 0.4
        mus = 0.5*1e6
        rhof = 1e3
        nuf = 1e-3
        U = 0.2
    elif(selection == 2):
        rhos = 1e4
        nus = 0.4
        mus = 0.5*1e6
        rhof = 1e3
        nuf = 1e-3
        U = 1
    elif(selection == 3):
        rhos = 1e3
        nus = 0.4
        mus = 2*1e6
        rhof = 1e3
        nuf = 1e-3
        U = 2
    else:
        print("Wrong input! Only supporting FSI 1,2 and 3!")
        rhos = 1
        nus = 1
        mus = 1
        rhof = 1
        nuf = 1e-3
        U = 2
    ls = 2*mus*nus/(1-2*nus)

    print("rhos = ", rhos)
    print("nus  = ", nus)
    print("ls   = ", ls)
    print("mus  = ", mus)
    print("rhof = ", rhof)
    print("nuf  = ", nuf)
    print("U0   = ", U)
    
    return (rhos, ls, mus, rhof, nuf, U)
