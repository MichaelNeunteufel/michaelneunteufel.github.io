from ngsolve import *
from netgen.geom2d import unit_square

mesh = Mesh(unit_square.GenerateMesh(maxh=0.02))

Draw (mesh)
for p in mesh.ngmesh.Points():
    px,py = p[0], p[1]
    p[0] += 3*py*(1-py)
Redraw()


gfu = GridFunction(H1(mesh, order=3))
gfu.Set(sin(10*x))

Draw(gfu, mesh, "gfu")
input("bad mesh")

mesh2 = Mesh(mesh.ngmesh.Copy())
mesh2.ngmesh.OptimizeMesh2d()

gfu2 = GridFunction(H1(mesh2, order=3))
gfu2.Set(gfu)

Draw(gfu2, mesh2, "gfu2")
