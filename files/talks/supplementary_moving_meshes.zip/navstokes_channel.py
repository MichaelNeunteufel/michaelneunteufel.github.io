from ngsolve import *
from netgen.geom2d import SplineGeometry
from ngsolve.internal import visoptions
from math import pi


geo = SplineGeometry()
geo.AddRectangle( (0,0), (2,1), bcs=("wall","outlet","wall","inlet") )
mesh = Mesh(geo.GenerateMesh(maxh=0.2))
Draw(mesh)

t    = 0
tau  = 1e-3
tend = 1

order = 4

def Deformation(t):
    return ( (0.3*sin(2*t*pi*x)*y*(1-y)*x*(2-x), 0.3*sin(2*t*pi*y)*x*(2-x)*y*(1-y)) )

fesset = H1(mesh, order=order, dirichlet="inlet|wall", dim=2)
U = VectorH1(mesh, order=order, dirichlet="inlet|wall")
Q = H1(mesh, order=order-1)
X = FESpace( [U,Q] )
(u,p),(v,q) = X.TnT()

gfsol    = GridFunction(X)
gfsolold = GridFunction(X)
gfset    = GridFunction(fesset)
gfsetold = GridFunction(fesset)

uold,pold = gfsolold.components

F = Grad(gfset) + Id(2)
J = Det(F)

stokes = J*(InnerProduct(grad(u)*Inv(F),grad(v)*Inv(F)) + p*Trace(grad(v)*Inv(F)) + q*Trace(grad(u)*Inv(F)) - 1e-10*p*q)*dx
conv   = J*InnerProduct(grad(u)*Inv(F)*(u-1/tau*(gfset-gfsetold)),v)*dx
mass   = J*u*v*dx

a = BilinearForm(X, symmetric=True)
a += stokes
a.Assemble()

m = BilinearForm(X, symmetric=True)
m += mass
m.Assemble()

mstar = a.mat.CreateMatrix()


b = BilinearForm(X, nonassemble=True)
b += conv

# initial value
gfsol.components[0].Set( CoefficientFunction( (y*(1-y),0) ), definedon=mesh.Boundaries("inlet") )

#Solve initial stokes problem
invstokes = a.mat.Inverse(X.FreeDofs(), inverse="umfpack")
r = gfsol.vec.CreateVector()
r.data = a.mat*gfsol.vec
gfsol.vec.data -= invstokes*r

Draw(gfsol.components[0], mesh, "u")
Draw(gfset, mesh, "deformation")
SetVisualization(deformation=True)
visoptions.scalfunction = 'u:0'

input("press enter to start")

with TaskManager():
  while t < tend:
    t += tau
    print("t = ", t)
    
    gfsetold.vec.data = gfset.vec
    gfset.Set(Deformation(t/tend))
    gfsolold.vec.data = gfsol.vec

    a.Assemble()
    m.Assemble()
    mstar.AsVector().data = m.mat.AsVector() + tau*a.mat.AsVector()
    
    b.Apply(gfsol.vec, r)
    r.data += a.mat*gfsol.vec

    inv = mstar.Inverse(X.FreeDofs(), inverse="umfpack")

    gfsol.vec.data -= tau*inv*r
    
    Redraw(blocking=True)
