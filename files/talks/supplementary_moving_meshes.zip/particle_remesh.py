from ngsolve import *
from ngsolve.internal import visoptions
from fsihelper import *
import ngsolve.internal

#Check mesh qualitiy by computing inner and outer radius of (deformed) triangles and compute ratio of them
def CheckQuality(mesh, gfu):
    gfqual = GridFunction(L2(mesh,order=0))
    gfset  = GridFunction(H1(mesh,order=order,dim=2))
    gfset.Set(gfu.components[2])
    
    mesh.SetDeformation(gfset)
    A = Integrate(1, mesh, VOL, element_wise=True)
    mesh.UnsetDeformation()
    
    for el in mesh.Elements(VOL):
        p = [list(mesh[el.vertices[i]].point) for i in range(3)]

        for j in range(3):
            diff = [0,0]
            for i in range(2):
                diff[i] = gfu.components[2](p[j][0],p[j][1])[i]
            for i in range(2):
                p[j][i] += diff[i]
    
        a = sqrt((p[0][0] - p[1][0])**2 + (p[0][1] - p[1][1])**2)
        b = sqrt((p[0][0] - p[2][0])**2 + (p[0][1] - p[2][1])**2)
        c = sqrt((p[2][0] - p[1][0])**2 + (p[2][1] - p[1][1])**2)

        R_r = a*b*c*(a+b+c)/(8*A[el.nr]**2)
        
        gfqual.vec[el.nr] = R_r
    return max(gfqual.vec)


def OptimizeMesh(mesh):
    # copy mesh and move points
    tmpngmesh = mesh.ngmesh.Copy()
    for p in tmpngmesh.Points():
        px,py = p[0], p[1]
        diffx = gfu.components[2](px,py)[0]
        diffy = gfu.components[2](px,py)[1]
        p[0] += diffx
        p[1] += diffy
    tmpmesh = Mesh(tmpngmesh)
    
    tmpV = VectorH1( tmpmesh, order=order, dirichlet="inlet|wall|outcyl" )
    tmpQ = H1( tmpmesh, order=order-1, definedon="fluid" )
    tmpD = VectorH1( tmpmesh, order=order, dirichlet="inlet|wall|outcyl|outlet" )
    tmpX = FESpace( [tmpV, tmpQ, tmpD] )
    gftmp = GridFunction(tmpX)

    gftmp.components[0].vec.data = gfu.components[0].vec
    gftmp.components[1].vec.data = gfu.components[1].vec

    # copy mesh and optimize it
    ngmesh2 = tmpmesh.ngmesh.Copy()
    ngmesh2.OptimizeMesh2d()
    mesh2 = Mesh(ngmesh2)

    V2 = VectorH1( mesh2, order=order )
    Q2 = H1( mesh2, order=order-1, definedon="fluid" )
    D2 = VectorH1( mesh2, order=order, dirichlet="inlet|wall|outcyl|outlet" )
    X2 = FESpace( [V2, Q2, D2] )
    gfu2 = GridFunction(X2)

    gfu2.components[0].Set(gftmp.components[0])
    gfu2.components[1].Set(gftmp.components[1])    

    return (mesh2, gfu2)


#Set up Fluid-Structure Interaction
def SetUp(mesh, gf=None):
    #Taylor Hood
    V = VectorH1( mesh, order=order, dirichlet="inlet|wall|outcyl" )
    Q = H1( mesh, order=order-1, definedon="fluid" )
    D = VectorH1( mesh, order=order, dirichlet="inlet|wall|outcyl|outlet" )
    X = FESpace( [V, Q, D] )
    Y = FESpace( [V, Q] )
    (u,p,d), (v,q,w)= X.TnT()
        
    #Gridfunctions
    gfu    = GridFunction(X)
    gfuold = GridFunction(X)
        
    velocity, pressure, deformation = gfu.components
    uold, pold, dold = gfuold.components
        
    graduold,graddold = grad(uold),grad(dold)
        
    I = Id(mesh.dim)
    (F,C,E,J,Finv)= CalcStresses(grad(d))
    (Fold,Cold,Eold,Jold,Finvold)= CalcStresses(graddold)
                
    #For Stokes problem
    stokes = BilinearForm(Y, symmetric=True, check_unused=False)
    stokes += (nuf*rhof*InnerProduct(grad(u), grad(v)) - div(u)*q - div(v)*p - 1e-9*p*q)*dx("fluid")
    stokes.Assemble()
        
    # Crank-Nicolson time integration scheme
    mass_fl = 0.5*rhof*InnerProduct((J+Jold)*(u-uold), v)*dx("fluid")
    diff_fl = (0.5*rhof*nuf*tau*(InnerProduct(J*grad(u)*Finv, grad(v)*Finv)+InnerProduct(Jold*graduold*Finvold, grad(v)*Finvold)))*dx("fluid")
    conv_fl = (0.5*rhof*tau*InnerProduct(J*(grad(u)*Finv)*u+Jold*(graduold*Finvold)*uold, v) -0.5*rhof*InnerProduct((J*grad(u)*Finv+Jold*graduold*Finvold)*(d-dold), v))*dx("fluid")
    pres_fl = -tau*J*(Trace(grad(v)*Finv)*p + Trace(grad(u)*Finv)*q + 1e-9*p*q)*dx("fluid")


    mass_sol = (rhos*InnerProduct(u-uold, v) + InnerProduct(tau/2*(u+uold)-(d-dold), w))*dx("solid")
    el_sol = (0.5*tau*InnerProduct(F*(2*mus*E+ls*Trace(E)*I) + Fold*(2*mus*Eold+ls*Trace(Eold)*I), grad(v)))*dx("solid")

        
    gfdist = GridFunction(H1(mesh, order=1, dirichlet="inlet|wall|outcyl|outlet"))
    gfdist.Set(1, definedon=mesh.Boundaries("interface"))
    def NeoHookExt(C, mu=1,lam=1):
        return 0.5*mu*(Trace(C-I) + 2*mu/lam*Det(C)**(-lam/2/mu) - 1)
    cf_extension = Variation(1e-8*NeoHookExt(C)*dx("fluid"))
        
    #Define big BilinearForm for Newton
    a = BilinearForm(X, symmetric=False, condense=True)
    a += mass_fl + diff_fl + conv_fl + pres_fl  + mass_sol + el_sol
    a += cf_extension
        

    if gf:
        gfu.vec.data = gf.vec
        gfuold.vec.data = gf.vec

    #Drawing stuff
    Draw(CoefficientFunction( [velocity if mat == "fluid" else None for mat in mesh.GetMaterials()] ), mesh, "velocity")
    Draw(pressure, mesh, "pressure")
    Draw(deformation, mesh, "deformation")
    visoptions.scalfunction = "velocity:0"
    visoptions.vecfunction = "deformation"
    SetVisualization(deformation=True)
    
    return (a, stokes, gfu, gfuold, Y)


tau   = Parameter(0.004)
t     = 0
tend  = 2.2
order = 2

mesh = GenerateMeshParticle()
Draw(mesh)
(rhos, ls, mus, rhof, nuf, U) = SetCoeff(2)

uinflow = CoefficientFunction( (4*U*1.5*y*(0.41-y)/(0.41*0.41),0) )

(a, stokes, gfu, gfuold, Y) = SetUp(mesh)

########  Stokes step ##########
bts = Y.FreeDofs() & ~Y.GetDofs(mesh.Materials("solid"))
bts &= ~Y.GetDofs(mesh.Boundaries("wall|inlet|outcyl|interface"))
bts[Y.Range(1)] = True
invstoke = stokes.mat.Inverse(bts, inverse = "sparsecholesky")

tmp = GridFunction(Y)
rstokes = tmp.vec.CreateVector()

tmp.components[0].Set( uinflow, BND,definedon=mesh.Boundaries("inlet") )
rstokes.data = stokes.mat*tmp.vec
tmp.vec.data -= invstoke*rstokes
gfu.components[0].vec.data = tmp.components[0].vec
gfu.components[1].vec.data = tmp.components[1].vec
Redraw(blocking=True)


input("<Press enter to start>")

with TaskManager():
    while t < tend-tau.Get()/2.0:
        t += tau.Get()
        print("t =", t)

        gfuold.vec.data = gfu.vec

        solvers.Newton(a, gfu, inverse="umfpack", printing=True, maxerr=1e-8)


        qual = CheckQuality(mesh,gfu)
        if qual > 8:
            (mesh, gf) = OptimizeMesh(mesh)
            (a, stokes, gfu, gfuold, Y) = SetUp(mesh, gf)
            
        Redraw()
