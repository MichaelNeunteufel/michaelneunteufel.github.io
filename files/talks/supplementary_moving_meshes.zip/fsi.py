from ngsolve import *
from ngsolve.internal import visoptions
from fsihelper import *
import ngsolve.internal

tau   = Parameter(0.005)
t     = 0
tend  = 5
order = 3

mesh = Generate2DMesh(order)

truecompile = False
def SolidBFI(term, **args):
    return SymbolicBFI(term.Compile(truecompile,wait=True), definedon=mesh.Materials("solid"), **args)
def FluidBFI(term, **args):
    return SymbolicBFI(term.Compile(truecompile,wait=True), definedon=mesh.Materials("fluid"), **args)

#define constants (FSI 2):
(rhos, ls, mus, rhof, nuf, U) = SetCoeff(2)
uinflow = CoefficientFunction( (4*U*1.5*y*(0.41-y)/(0.41*0.41),0) )

#Taylor Hood
V = VectorH1( mesh, order=order, dirichlet="inlet|wall|circ|circ2" )
Q = H1( mesh, order=order-1, definedon="fluid" )
D = VectorH1( mesh, order=order, dirichlet="inlet|wall|circ|circ2|outlet" )
X = FESpace( [V, Q, D] )
Y = FESpace( [V, Q] )
(u,p,d),(v,q,w) = X.TnT()

#Gridfunctions
gfu    = GridFunction(X)
gfuold = GridFunction(X)

#Extract variables
velocity, pressure, deformation = gfu.components
uold, pressureold, dold = gfuold.components

graduold = grad(gfuold.components[0])
graddold = grad(gfuold.components[2])


I = Id(2)
(F,C,E,J,Finv) = CalcStresses(grad(d))
(Fold,Cold,Eold,Jold,Finvold) = CalcStresses(graddold)


#For Stokes problem
stokes = BilinearForm ( Y, symmetric=True, check_unused=False )
stokes += (nuf*rhof*InnerProduct(grad(u), grad(v)) - div(u)*q - div(v)*p - 1e-9*p*q)*dx("fluid")
stokes.Assemble()


mass_fl = 0.5*rhof*InnerProduct((J+Jold)*(u-uold), v)
diff_fl = 0.5*rhof*nuf*tau*(InnerProduct(J*grad(u)*Finv, grad(v)*Finv)+InnerProduct(Jold*graduold*Finvold, grad(v)*Finvold))
conv_fl = 0.5*rhof*tau*InnerProduct(J*(grad(u)*Finv)*u+Jold*(graduold*Finvold)*uold, v) -0.5*rhof*InnerProduct((J*grad(u)*Finv+Jold*graduold*Finvold)*(d-dold), v)
pres_fl = -tau*J*(Trace(grad(v)*Finv)*p + Trace(grad(u)*Finv)*q + 1e-9*p*q)


mass_sol = rhos*InnerProduct(u-uold, v) + InnerProduct(tau/2*(u+uold)-(d-dold), w)
el_sol = 0.5*tau*InnerProduct(F*(2*mus*E+ls*Trace(E)*I) + Fold*(2*mus*Eold+ls*Trace(Eold)*I), grad(v))

gfdist = GridFunction(H1(mesh, order=1, dirichlet="inlet|wall|outcyl|outlet"))
gfdist.Set(1, definedon=mesh.Boundaries("interface"))
def NeoHookExt(C, mu=1,lam=1):
    return 0.5*mu*(Trace(C-I) + 2*mu/lam*Det(C)**(-lam/2/mu) - 1)
cf_extension = 1e-8*NeoHookExt(C)

#Define big BilinearForm for Newton
a = BilinearForm( X, symmetric=False, condense=True )
a += FluidBFI( mass_fl + diff_fl + conv_fl + pres_fl )
a += SolidBFI( mass_sol + el_sol )
a += SymbolicEnergy( (1/(1-gfdist+1e-2)*cf_extension).Compile(truecompile,wait=True), definedon=mesh.Materials("fluid") )


#Drawing stuff
Draw(CoefficientFunction( [velocity if mat == "fluid" else None for mat in mesh.GetMaterials()]), mesh, "velocity")
Draw(pressure, mesh, "pressure")
Draw(deformation, mesh, "deformation")
visoptions.scalfunction = "velocity:0"
visoptions.vecfunction  = "deformation"
SetVisualization( deformation=True)

#for stokes step
bts = Y.FreeDofs() & ~Y.GetDofs(mesh.Materials("solid"))
bts &= ~Y.GetDofs(mesh.Boundaries("wall|inlet|circ|circ2|interface"))
bts[Y.Range(1)] = True      

invstoke = stokes.mat.Inverse(bts, inverse = "sparsecholesky")

rstokes = GridFunction(Y)
tmp = GridFunction(Y)

tmp.components[0].Set( uinflow, definedon=mesh.Boundaries("inlet") )
rstokes.vec.data = stokes.mat*tmp.vec
tmp.vec.data -= invstoke*rstokes.vec
gfu.components[0].vec.data += tmp.components[0].vec
gfu.components[1].vec.data += tmp.components[1].vec

Redraw()

input("<Press enter to start>")
Redraw(blocking=True)

with TaskManager():
    while t < tend-tau.Get()/2.0:
        t += tau.Get()
        print("t = ", t)
        gfuold.vec.data = gfu.vec
        
        solvers.Newton(a, gfu, maxit=10, maxerr=1e-8, printing=True, inverse="umfpack")
        Redraw(blocking=True)
        
