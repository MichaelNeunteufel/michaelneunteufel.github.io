mkdir build
cd build/
cmake  -DCMAKE_C_COMPILER=/usr/bin/gcc-11 -DCMAKE_CXX_COMPILER=/usr/bin/g++-11 ..
make install



% Use the same compilers as for NGSolve!
