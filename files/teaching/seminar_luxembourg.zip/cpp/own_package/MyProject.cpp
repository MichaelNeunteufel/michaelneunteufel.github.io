#include <solve.hpp>
#include <python_comp.hpp>
#include <python_fem.hpp>

//using namespace ngsolve;
//using namespace ngfem;
//using namespace ngcomp;

#include "myElement_lo.hpp"
#include "myFESpace_lo.hpp"
#include "myDiffOp_lo.hpp"



PYBIND11_MODULE(MyProject,m) {
  // import ngsolve such that python base classes are defined
  auto ngs = py::module::import("ngsolve");

   ExportMyFESpace(m);


}
